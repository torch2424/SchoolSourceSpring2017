# How to compile

Within directory:
`javac *.java`

# How to run

`java ChordUser`

# Javadocs

Generate Javadocs from within the javaDoc directory: `javadoc -private ../ChordUser.java`

# Nice Java Docs Cheat sheet
https://binfalse.de/2015/10/05/javadoc-cheats-sheet/

# Example Video (Ran in Debug Mode for Verbosity)
[![Youtube Embed](http://img.youtube.com/vi/14j5GRb6LvM/0.jpg)](http://www.youtube.com/watch?v=14j5GRb6LvM)

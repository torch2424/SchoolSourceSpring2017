# Ftp Client Project README

A nice alternative ftp server: ftp://speedtest.tele2.net

# Due Feb, 9th
